package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

//싱글톤패턴 (singleton pattern)
//일종의 utility 클래스
public class DBConn {

	private static Connection con; // priavte: 클래스 내에서만 , static : 공유해서 사용

	
	// 1. 외부에서 접근할 수 없는 기본생성자 작성
	// private 생성자이므로 다른 곳에서 new DBConn 으로 객체 생성이 불가능
	// 커넥션을 하나만 만들어서 여러 번 쓸 건데, public 생성자면 생성할 때마다 커넥션이 생겨버림
	// 그래서 생성자를 잠궈놓고, getConnection만 public static로 열어둬서 이 메서드만 공유해서 사용하도록
	private DBConn() {} 	

	
	
	// 2. getConnection() 작성(접근 제한X)
	// 커넥션 객체를 생성하고 반환하는 공유 메서드
	public static Connection getConnection() {

		String driver = "oracle.jdbc.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String username = "dev";
		String password = "0000";

		if (con == null) {	// Connection 객체가 null인 경우에만 -> connection객체가 이미 있으면 만들 필요 없으니까
			try {
				Class.forName(driver);		// 드라이버 로딩
				con = DriverManager.getConnection(url, username, password);
			} catch (ClassNotFoundException e) {	// 클래스 로딩 시 jar파일이 없는 예외가 발생할 수 있어서 잡아주는 것
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return con;

	} // getConnection end
	
	
	// JDBC 과정
	// DBMS 설치, 거기에 맞는 JDBC 드라이버 설치, 드라이버 로딩, 커넥션 객체 생성, 
	
	
	
	
	// 3. Statement 객체를 매개변수로 받아서 닫는 메서드 close() 작성 (접근 제한X)
	public static void close(Statement stmt) {

		try {
			// pstmt 객체가 널이 아닌 경우에만 각각 닫기 처리
			if (stmt != null)
				stmt.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	
	// 4. PreparedStatement 객체를 매개변수로 받아서 닫는 공유 메서드 close() 작성 (접근 제한X)
	public static void close(PreparedStatement pstmt) {
		try {
			// pstmt 및 con 객체가 널이 아닌 경우에만 각각 닫기 처리
			if (pstmt != null)
				pstmt.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	
	
	
	// 5. PreparedStatement, ResultSet 객체를 매개변수로 받아서 닫는 공유 메서드 close() 작성
	public static void close(PreparedStatement pstmt, ResultSet rs) {
		try {
			if (pstmt != null)
				pstmt.close();
			if (rs != null)
				rs.close(); // 역순으로 close 해야 하므로, rs 먼저 닫은 후 pstmt 닫음
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	
	// 6. 매개변수를 받지 않고 Connection 클래스의 객체 con을 종료하는 공유 메서드 close() 작성
	// DBConn클래스에서 con을 private static으로 했기 때문에 외부에서 직접 닫을 순 없음. 그래서 public 메서드 필요
	public static void close() {
		try {
			if(con!=null)
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	
	

}	// class end
